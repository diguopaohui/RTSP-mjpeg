#include "RtspService.h"
#include "RtspInterface.h"

void Rtsp_Init()
{
	RtspService *pRtspService = GetRtspServiceInstance();
	pRtspService->Start();	
}

void get_Jpeg_data(unsigned char* data, int len)
{

	RtspService *pRtspService = GetRtspServiceInstance();
	pRtspService->getJPEGData(data,  len);
}














