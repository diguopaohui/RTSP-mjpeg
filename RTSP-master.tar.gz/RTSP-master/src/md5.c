/*
 * MD5C.C - RSA Data Security, Inc., MD5 message-digest algorithm
 */

/*
 * Copyright (C) 1991-2, RSA Data Security, Inc. Created 1991. All rights
 * reserved.
 * 
 * License to copy and use this software is granted provided that it is
 * identified as the "RSA Data Security, Inc. MD5 Message-Digest Algorithm"
 * in all material mentioning or referencing this software or this function.
 * 
 * License is also granted to make and use derivative works provided that such
 * works are identified as "derived from the RSA Data Security, Inc. MD5
 * Message-Digest Algorithm" in all material mentioning or referencing the
 * derived work.
 * 
 * RSA Data Security, Inc. makes no representations concerning either the
 * merchantability of this software or the suitability of this software for
 * any particular purpose. It is provided "as is" without express or implied
 * warranty of any kind.
 * 
 * These notices must be retained in any copies of any part of this
 * documentation and/or software.
 */

 
//by qiaohaijun from live555

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "md5.h"

static const char BaseTable[66]="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/="; 
//---------------------------------------------------------------------------
unsigned char FindInTable(unsigned char c)
{
    int i=0;
    for(i=0;i<65;i++)
    {
        if(BaseTable[i]==c)
        {
            return i;
        }
    }
	return 0;
}
//---------------------------------------------------------------------------
char * DecodeBase64(char* Source)
{
    unsigned char x1,x2,x3,x4,xt;
    int SrcLen,Times,i,iResult=0;
    char* Result=(char*)malloc(512);

	if (NULL == Result)
	{
		return NULL;
	}
	
    memset(Result,0,512);

    SrcLen=strlen(Source);
    Times=SrcLen / 4;
    for(i=0;i<Times;i++)
    {
        x1=FindInTable(Source[0+i*4]);
        x2=FindInTable(Source[1+i*4]);
        x3=FindInTable(Source[2+i*4]);
        x4=FindInTable(Source[3+i*4]);

        x1<<=2;
        xt=x2>>4;
        x1=x1 | xt;
        Result[iResult++]=x1;

        x2<<=4;
        if (x3==64)
        {
            break;
        }
        xt=x3>>2;
        x2=x2 | xt;
        x3<<=6;
        Result[iResult++]=x2;

        if (x4==64)
        {
            break;
        }
        x3=x3 | x4;
        Result[iResult++]=x3;
    }
    return Result;
}
//---------------------------------------------------------------------------
//char* EncodeBase64(char* Source)
int EncodeBase64(char* Result,char* Source)
{
    int Times,LenSrc,i,iResult=0;
    unsigned char x1,x2,x3,x4,xt,xt1;
    //char* Result=(char*)malloc(512);
    //memset(Result,0,512);
    LenSrc=strlen(Source);
    if (LenSrc % 3==0) Times=LenSrc/3;
    else Times=LenSrc/3+1;
    for(i=0;i<Times;i++)
    {
        if (LenSrc>=(3*i+3))
        {
            xt=Source[0+i*3];
            xt>>=2;
            x1=BaseTable[xt];
            xt=Source[0+i*3];
            xt<<=4;
            xt&=48;
            xt1=Source[1+i*3];
            xt1>>=4;
            xt|=xt1;
            x2=BaseTable[xt];
            xt=Source[1+i*3];
            xt<<=2;
            xt&=60;
            xt1=Source[2+i*3];
            xt1>>=6;
            xt|=xt1;
            x3=BaseTable[xt];
            xt=Source[2+i*3] ;
            xt&=63;
            x4=BaseTable[xt];
        }
        else if (LenSrc>=3*i+2)
        {
            xt=Source[0+i*3];
            xt>>=2;
            x1=BaseTable[xt];
            xt=Source[0+i*3];
            xt<<=4;
            xt&=48;
            xt1=Source[1+i*3];
            xt1>>=4;
            xt|=xt1;
            x2=BaseTable[xt];
            xt=Source[1+i*3];
            xt<<=2;
            xt&= 60;
            x3=BaseTable[xt];
            x4='=';
        }
        else
        {
            xt=Source[0+i*3];
            xt>>=2;
            x1=BaseTable[xt];
            xt=Source[0+i*3] ;
            xt<<=4;
            xt&=48;
            x2=BaseTable[xt];
            x3='=';
            x4='=';
        }

        Result[iResult++]=(char)(x1);
        Result[iResult++]=(char)(x2);
        Result[iResult++]=(char)(x3);
        Result[iResult++]=(char)(x4);
    }
    //return Result;
    return 0;
}


/*
 * Constants for MD5Transform routine.
 */
#define S11 7
#define S12 12
#define S13 17
#define S14 22

#define S21 5
#define S22 9
#define S23 14
#define S24 20

#define S31 4
#define S32 11
#define S33 16
#define S34 23

#define S41 6
#define S42 10
#define S43 15
#define S44 21

static unsigned char PADDING[64] = {
	0x80, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
};

/*
 * F, G, H and I are basic MD5 functions.
 */
#define F(x, y, z) (((x) & (y)) | ((~x) & (z)))
#define G(x, y, z) (((x) & (z)) | ((y) & (~z)))
#define H(x, y, z) ((x) ^ (y) ^ (z))
#define I(x, y, z) ((y) ^ ((x) | (~z)))

/*
 * ROTATE_LEFT rotates x left n bits.
 */
#define ROTATE_LEFT(x, n) (((x) << (n)) | ((x) >> (32-(n))))

/*
 * FF, GG, HH, and II transformations for rounds 1, 2, 3, and 4. Rotation is
 * separate from addition to prevent recomputation.
 */
#define FF(a, b, c, d, x, s, ac) { \
 (a) += F ((b), (c), (d)) + (x) + (UNSIGNED32)(ac); \
 (a) = ROTATE_LEFT ((a), (s)); \
 (a) += (b); \
  }
#define GG(a, b, c, d, x, s, ac) { \
 (a) += G ((b), (c), (d)) + (x) + (UNSIGNED32)(ac); \
 (a) = ROTATE_LEFT ((a), (s)); \
 (a) += (b); \
  }
#define HH(a, b, c, d, x, s, ac) { \
 (a) += H ((b), (c), (d)) + (x) + (UNSIGNED32)(ac); \
 (a) = ROTATE_LEFT ((a), (s)); \
 (a) += (b); \
  }
#define II(a, b, c, d, x, s, ac) { \
 (a) += I ((b), (c), (d)) + (x) + (UNSIGNED32)(ac); \
 (a) = ROTATE_LEFT ((a), (s)); \
 (a) += (b); \
  }

/*
 * Encodes input (UNSIGNED32) into output (unsigned char). Assumes len is a
 * multiple of 4.
 */
 
 /*
 *将4字节的整数copy到字符形式的缓冲区中
 *output：用于输出的字符缓冲区
 *input：欲转换的四字节的整数形式的数组
 *len：output缓冲区的长度，要求是4的整数倍
 */
static void 
Encode(unsigned char *output, UNSIGNED32 * input, unsigned int len)
{
	unsigned int    i, j;

	for (i = 0, j = 0; j < len; i++, j += 4) {
		output[j] = (unsigned char) (input[i] & 0xff);
		output[j + 1] = (unsigned char) ((input[i] >> 8) & 0xff);
		output[j + 2] = (unsigned char) ((input[i] >> 16) & 0xff);
		output[j + 3] = (unsigned char) ((input[i] >> 24) & 0xff);
	}
}

/*
 * Decodes input (unsigned char) into output (UNSIGNED32). Assumes len is a
 * multiple of 4.
 */
 /*
 *与上面的函数正好相反，这一个把字符形式的缓冲区中的数据copy到4字节的整数中（即以整数形式保存）
 *output：保存转换出的整数
 *input：欲转换的字符缓冲区
 *len：输入的字符缓冲区的长度，要求是4的整数倍
 */
static void 
Decode(UNSIGNED32 * output, unsigned char const *input, unsigned int len)
{
	unsigned int    i, j;

	for (i = 0, j = 0; j < len; i++, j += 4)
	{
		output[i] = ((UNSIGNED32) input[j]) 
		| (((UNSIGNED32) input[j + 1]) << 8) 
		| (((UNSIGNED32) input[j + 2]) << 16)
		| (((UNSIGNED32) input[j + 3]) << 24);
	}
}

/*
 * MD5 basic transformation. Transforms state based on block.
 */
static void 
MD5Transform(UNSIGNED32 state[4], const unsigned char block[64])
{
	UNSIGNED32 a = state[0], b = state[1], c = state[2], d = state[3], x[16];

	Decode(x, block, 64);

	/* Round 1 */
	FF(a, b, c, d, x[0], S11, 0xd76aa478);		/* 1 */
	FF(d, a, b, c, x[1], S12, 0xe8c7b756);		/* 2 */
	FF(c, d, a, b, x[2], S13, 0x242070db);		/* 3 */
	FF(b, c, d, a, x[3], S14, 0xc1bdceee);		/* 4 */
	FF(a, b, c, d, x[4], S11, 0xf57c0faf);		/* 5 */
	FF(d, a, b, c, x[5], S12, 0x4787c62a);		/* 6 */
	FF(c, d, a, b, x[6], S13, 0xa8304613);		/* 7 */
	FF(b, c, d, a, x[7], S14, 0xfd469501);		/* 8 */
	FF(a, b, c, d, x[8], S11, 0x698098d8);		/* 9 */
	FF(d, a, b, c, x[9], S12, 0x8b44f7af);		/* 10 */
	FF(c, d, a, b, x[10], S13, 0xffff5bb1);	/* 11 */
	FF(b, c, d, a, x[11], S14, 0x895cd7be);	/* 12 */
	FF(a, b, c, d, x[12], S11, 0x6b901122);	/* 13 */
	FF(d, a, b, c, x[13], S12, 0xfd987193);	/* 14 */
	FF(c, d, a, b, x[14], S13, 0xa679438e);	/* 15 */
	FF(b, c, d, a, x[15], S14, 0x49b40821);	/* 16 */

	/* Round 2 */
	GG(a, b, c, d, x[1], S21, 0xf61e2562);	/* 17 */
	GG(d, a, b, c, x[6], S22, 0xc040b340);	/* 18 */
	GG(c, d, a, b, x[11], S23, 0x265e5a51);	/* 19 */
	GG(b, c, d, a, x[0], S24, 0xe9b6c7aa);	/* 20 */
	GG(a, b, c, d, x[5], S21, 0xd62f105d);	/* 21 */
	GG(d, a, b, c, x[10], S22, 0x2441453);	/* 22 */
	GG(c, d, a, b, x[15], S23, 0xd8a1e681);	/* 23 */
	GG(b, c, d, a, x[4], S24, 0xe7d3fbc8);	/* 24 */
	GG(a, b, c, d, x[9], S21, 0x21e1cde6);	/* 25 */
	GG(d, a, b, c, x[14], S22, 0xc33707d6);	/* 26 */
	GG(c, d, a, b, x[3], S23, 0xf4d50d87);	/* 27 */
	GG(b, c, d, a, x[8], S24, 0x455a14ed);	/* 28 */
	GG(a, b, c, d, x[13], S21, 0xa9e3e905);	/* 29 */
	GG(d, a, b, c, x[2], S22, 0xfcefa3f8);	/* 30 */
	GG(c, d, a, b, x[7], S23, 0x676f02d9);	/* 31 */
	GG(b, c, d, a, x[12], S24, 0x8d2a4c8a);	/* 32 */

	/* Round 3 */
	HH(a, b, c, d, x[5], S31, 0xfffa3942);	/* 33 */
	HH(d, a, b, c, x[8], S32, 0x8771f681);	/* 34 */
	HH(c, d, a, b, x[11], S33, 0x6d9d6122);	/* 35 */
	HH(b, c, d, a, x[14], S34, 0xfde5380c);	/* 36 */
	HH(a, b, c, d, x[1], S31, 0xa4beea44);	/* 37 */
	HH(d, a, b, c, x[4], S32, 0x4bdecfa9);	/* 38 */
	HH(c, d, a, b, x[7], S33, 0xf6bb4b60);	/* 39 */
	HH(b, c, d, a, x[10], S34, 0xbebfbc70);	/* 40 */
	HH(a, b, c, d, x[13], S31, 0x289b7ec6);	/* 41 */
	HH(d, a, b, c, x[0], S32, 0xeaa127fa);	/* 42 */
	HH(c, d, a, b, x[3], S33, 0xd4ef3085);	/* 43 */
	HH(b, c, d, a, x[6], S34, 0x4881d05);		/* 44 */
	HH(a, b, c, d, x[9], S31, 0xd9d4d039);	/* 45 */
	HH(d, a, b, c, x[12], S32, 0xe6db99e5);	/* 46 */
	HH(c, d, a, b, x[15], S33, 0x1fa27cf8);	/* 47 */
	HH(b, c, d, a, x[2], S34, 0xc4ac5665);	/* 48 */

	/* Round 4 */
	II(a, b, c, d, x[0], S41, 0xf4292244);		/* 49 */
	II(d, a, b, c, x[7], S42, 0x432aff97);		/* 50 */
	II(c, d, a, b, x[14], S43, 0xab9423a7);	/* 51 */
	II(b, c, d, a, x[5], S44, 0xfc93a039);		/* 52 */
	II(a, b, c, d, x[12], S41, 0x655b59c3);	/* 53 */
	II(d, a, b, c, x[3], S42, 0x8f0ccc92);		/* 54 */
	II(c, d, a, b, x[10], S43, 0xffeff47d);	/* 55 */
	II(b, c, d, a, x[1], S44, 0x85845dd1);		/* 56 */
	II(a, b, c, d, x[8], S41, 0x6fa87e4f);		/* 57 */
	II(d, a, b, c, x[15], S42, 0xfe2ce6e0);	/* 58 */
	II(c, d, a, b, x[6], S43, 0xa3014314);		/* 59 */
	II(b, c, d, a, x[13], S44, 0x4e0811a1);	/* 60 */
	II(a, b, c, d, x[4], S41, 0xf7537e82);		/* 61 */
	II(d, a, b, c, x[11], S42, 0xbd3af235);	/* 62 */
	II(c, d, a, b, x[2], S43, 0x2ad7d2bb);		/* 63 */
	II(b, c, d, a, x[9], S44, 0xeb86d391);		/* 64 */

	state[0] += a;
	state[1] += b;
	state[2] += c;
	state[3] += d;

	/*
	 * Zeroize sensitive information.
	 */
	memset((unsigned char *) x, 0, sizeof(x));
}

/**
 * our_MD5Init:
 * @context: MD5 context to be initialized.
 * 
 * Initializes MD5 context for the start of message digest computation.
 **/
void 
our_MD5Init(MD5_CTX * context)
{
	context->count[0] = context->count[1] = 0;
	/* Load magic initialization constants.  */
	context->state[0] = 0x67452301;
	context->state[1] = 0xefcdab89;
	context->state[2] = 0x98badcfe;
	context->state[3] = 0x10325476;
}

/**
 * our_MD5Update:
 * @context: MD5 context to be updated.
 * @input: pointer to data to be fed into MD5 algorithm.
 * @inputLen: size of @input data in bytes.
 * 
 * MD5 block update operation. Continues an MD5 message-digest operation,
 * processing another message block, and updating the context.
 **/

void 
our_MD5Update(MD5_CTX * context, const unsigned char *input, unsigned int inputLen)
{
	unsigned int    i, index, partLen;

	/* Compute number of bytes mod 64 */
	index = (unsigned int) ((context->count[0] >> 3) & 0x3F);

	/* Update number of bits */
	if((context->count[0] += ((UNSIGNED32) inputLen << 3)) < ((UNSIGNED32) inputLen << 3))
	{
		context->count[1]++;
	}
	context->count[1] += ((UNSIGNED32) inputLen >> 29);

	partLen = 64 - index;

	/* Transform as many times as possible.  */
	if(inputLen >= partLen)
	{
		memcpy((unsigned char *) & context->buffer[index], (unsigned char *) input, partLen);
		MD5Transform(context->state, context->buffer);

		for (i = partLen; i + 63 < inputLen; i += 64)
		{
			MD5Transform(context->state, &input[i]);
		}
		index = 0;
	} 
	else
	{
		i = 0;
	}
	/* Buffer remaining input */
	if((inputLen - i) != 0)
	{
		memcpy((unsigned char *) & context->buffer[index], (unsigned char *) & input[i], inputLen - i);
	}
}

/**
 * our_MD5Final:
 * @digest: 16-byte buffer to write MD5 checksum.
 * @context: MD5 context to be finalized.
 * 
 * Ends an MD5 message-digest operation, writing the the message
 * digest and zeroing the context.  The context must be initialized
 * with our_MD5Init() before being used for other MD5 checksum calculations.
 **/

void 
our_MD5Final(unsigned char digest[16], MD5_CTX * context)
{
	unsigned char   bits[8];
	unsigned int    index, padLen;

	/* Save number of bits */
	Encode(bits, context->count, 8);

	/*
	 * Pad out to 56 mod 64.
	 */
	index = (unsigned int) ((context->count[0] >> 3) & 0x3f);
	padLen = (index < 56) ? (56 - index) : (120 - index);
	our_MD5Update(context, PADDING, padLen);

	/* Append length (before padding) */
	our_MD5Update(context, bits, 8);
	/* Store state in digest */
	Encode(digest, context->state, 16);

	/*
	 * Zeroize sensitive information.
	 */
	memset((unsigned char *) context, 0, sizeof(*context));
}

#define MD5_EN_LEN 16
int our_MD5_Encrypt(unsigned char*_pBuf, unsigned int _uiLen, unsigned char *_pOutDecrypt, int _iOutLen)
{    
    unsigned char decrypt[MD5_EN_LEN +1] = {0};    
    MD5_CTX md5;
    int i = 0;
    int iStrUsedLen = 0;
    int iStrWidth = 2;

    if(NULL == _pBuf || NULL == _pOutDecrypt)
    {
        printf("NULL == _pBuf || NULL == _pOutDecrypt");
        return -1;
    }

    if(_uiLen == 0 || _iOutLen == 0)
    {
        printf("_uiLen=%u _iOutLen=%u", _uiLen, _iOutLen);
        return -1;
    }
    
    our_MD5Init(&md5);                         //初始化用于md5加密的结构
    our_MD5Update(&md5, (const unsigned char *)_pBuf,_uiLen);   //对欲加密的字符进行加密
    our_MD5Final(decrypt,&md5);
       
    for(i = 0; i < MD5_EN_LEN && iStrUsedLen < _iOutLen; i++)
    {        
        iStrUsedLen += (int)snprintf(((char*)_pOutDecrypt + (iStrWidth*i)), (unsigned int)(iStrWidth+1), "%02X", decrypt[i]);        
    }    
    
    return iStrUsedLen;
}

#ifndef MD5_BUFSIZ //pocket pc
#define MD5_BUFSIZ 255
#endif

#define DIGEST_LENGTH 16

char *
our_MD5End(MD5_CTX *ctx, char *buf)
{
    int i;
    unsigned char digest[DIGEST_LENGTH];
    static const char hex[]="0123456789abcdef";

    if (!buf)
        buf = (char*)malloc(2*DIGEST_LENGTH + 1);
    if (!buf)
	return 0;
    our_MD5Final(digest, ctx);
    for (i = 0; i < DIGEST_LENGTH; i++) {
	buf[i+i] = hex[digest[i] >> 4];
	buf[i+i+1] = hex[digest[i] & 0x0f];
    }
    buf[i+i] = '\0';
    return buf;
}

char *
our_MD5File(const char *filename, char *buf)
{
    unsigned char buffer[MD5_BUFSIZ];
    MD5_CTX ctx;
    int i;
	FILE* f;

    our_MD5Init(&ctx);
    f = fopen(filename, "r");
    if (f == NULL) return 0;
    while ((i = fread(buffer,1,sizeof buffer,f)) > 0) {
	our_MD5Update(&ctx,buffer,i);
    }
    fclose(f);
    if (i < 0) return 0;
    return our_MD5End(&ctx, buf);
}

char *
our_MD5Data (const unsigned char *data, unsigned int len, char *buf)
{
    MD5_CTX ctx;

    our_MD5Init(&ctx);
    our_MD5Update(&ctx,data,len);
    return our_MD5End(&ctx, buf);
}



#if 0
int main(int argc, char* argv[])
{
	MD5_CTX md5;

	unsigned char encrypt[200];     //存放于加密的信息
	unsigned char decrypt[17];       //存放加密后的结果
	scanf("%s",encrypt);                 //输入加密的字符

	our_MD5Init(&md5);                         //初始化用于md5加密的结构
	our_MD5Update(&md5,encrypt,strlen((char *)encrypt));   //对欲加密的字符进行加密
	our_MD5Final(decrypt,&md5);                                            //获得最终结果
 
 	printf("before:%s\nafter:",encrypt);

 	char tmp[3] = {0};
 	char tmp2[34] = {0};

	int i = 0;
	for(i = 0; i < 16; i++)
	{
		printf("%02X", decrypt[i]);
	//	strcat(tmp2, tmp);
	}

	//printf("tmp2 ====== %s", tmp2);
 

 printf("\n\n\nencode over!\n");
 
 return 0;
}
#endif



