#ifndef _RTSP_INTERFACE_H_
#define _RTSP_INTERFACE_H_

#ifdef __cplusplus
extern "C" {
#endif


void Rtsp_Init();


void get_Jpeg_data(unsigned char* data, int len);









#ifdef __cplusplus
}
#endif

















#endif

